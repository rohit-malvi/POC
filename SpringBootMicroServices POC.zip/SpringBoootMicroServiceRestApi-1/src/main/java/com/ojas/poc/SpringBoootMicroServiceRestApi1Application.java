package com.ojas.poc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@EnableEurekaClient
@SpringBootApplication
public class SpringBoootMicroServiceRestApi1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoootMicroServiceRestApi1Application.class, args);
	}

}
