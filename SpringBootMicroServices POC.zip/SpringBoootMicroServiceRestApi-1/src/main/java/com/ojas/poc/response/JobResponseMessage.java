
package com.ojas.poc.response;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "job")
public class JobResponseMessage<T> {

	@XmlElement(name = "status")
	private ResponseStatus status;

	@XmlElement(name = "jobEntity")
	private T entity;

	public T getEntity() {
		return entity;
	}

	public void setEntity(T entity) {
		this.entity = entity;
	}

	public JobResponseMessage() {
		super();
	}

	public JobResponseMessage(ResponseStatus status, T entity) {
		super();
		this.status = status;
		this.entity = entity;
	}

	public JobResponseMessage(T entity) {
		super();
		setEntity(entity);
	}

	public JobResponseMessage(ResponseStatus status2, int userId) {
		// TODO Auto-generated constructor stub
	}
}