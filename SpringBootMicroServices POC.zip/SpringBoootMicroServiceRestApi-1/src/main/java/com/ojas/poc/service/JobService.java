package com.ojas.poc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ojas.poc.dao.ExcelImpl;
import com.ojas.poc.dao.JobRepository;
import com.ojas.poc.exception.ResourceNotFoundException;
import com.ojas.poc.model.Job;

@Service
public class JobService {

	@Autowired
	private JobRepository jobRepository;

	@Autowired
	private ExcelImpl excelDao;

	public int createJob(Job job) {
		return excelDao.createJob(job);
	}

	public Job getJobById(int jobId) {
		return jobRepository.findById(jobId)
				.orElseThrow(() -> new ResourceNotFoundException("Records are not available with jobId" + jobId));
	}

	public List<Job> getAllJob() {
		return jobRepository.findAll();
	}

	public List<Job> findJobByCountry(String country) {
		return jobRepository.findJobByCountry(country);
	}

	public List<Job> findJobByLanguage(String lang) {
		return jobRepository.findJobByLanguage(lang);
	}

	public List<Job> findJobByJobType(String type) {
		return jobRepository.findJobByJobType(type);
	}

	public List<Job> findJobByExperience(int exp) {
		return jobRepository.findJobByExperience(exp);
	}

	public List<Job> findJobBySkill(String skill) {

		// TODO Auto-generated method stub
		return jobRepository.findJobBySkills(skill);
	}

	public List<Job> findJobByPayRate(int payRate) {
		// TODO Auto-generated method stub
		return jobRepository.findJobByPayRate(payRate);
	}

	public List<Job> findJobByAvailability(String availabiltyList) {
		// TODO Auto-generated method stub
		return jobRepository.findJobByAvailability(availabiltyList);
	}

}
