package com.ojas.poc.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.ojas.poc.exception.ResourceNotFoundException;
import com.ojas.poc.helper.ExcelHelper1;
import com.ojas.poc.model.Job;
import com.ojas.poc.response.JobResponseMessage;
import com.ojas.poc.response.JobsResponseMessage;
import com.ojas.poc.response.ResponseStatus;
import com.ojas.poc.response.ResponseStatusCode;
import com.ojas.poc.service.JobService;
import com.ojas.poc.service.UserInfoService;

@RestController
@RequestMapping(value = "/poc/job")
public class JobController {

	private static final Logger log = Logger.getLogger(JobController.class);

	@Autowired
	private JobService jobService;

	@Autowired
	private UserInfoService userService;

	@Autowired
	private ExcelHelper1 excelHelper;

	@PostMapping("/saveJob")
	public JobResponseMessage<Job> createJob(@RequestBody Job job) {
		ResponseStatus status = null;
		int id = jobService.createJob(job);
		if (id > 0) {
			status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "SUCCESS");
			log.info("job saved successfully");
		} else {
			status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "No Record found");
			throw new ResourceNotFoundException("records are not available" + job);

		}

		return new JobResponseMessage<Job>(status, job);
	}

	@GetMapping("/getId/{jobId}")
	public JobResponseMessage<Job> getJobById(@PathVariable int jobId) {
		log.info("request");
		ResponseStatus status = null;
		if (jobService.getJobById(jobId) != null) {
			log.info("job found with the id" + jobId);
			status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "SUCCESS");
		} else {
			log.error("job is not found with jobId" + jobId);
			status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "No Record found");
			throw new ResourceNotFoundException("jobId" + jobId);
		}
		return new JobResponseMessage<Job>(status, jobService.getJobById(jobId));

	}

	@GetMapping("/getAll")
	public JobsResponseMessage getAllJob() {
		ResponseStatus status = null;
		if (jobService.getAllJob() != null) {
			log.info("all job found");
			status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "SUCCESS");
		} else {
			log.error("records are not found");
			status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "No Record found");
			throw new ResourceNotFoundException("getAll Job not having any records");
		}
		return new JobsResponseMessage(status, jobService.getAllJob());

	}

	@GetMapping("/getCountry/{country}")
	public JobsResponseMessage getJobByCountry(@PathVariable("country") String country) {

		ResponseStatus status = null;
		List<Job> job = jobService.findJobByCountry(country);
		if (job != null) {
			log.info("job are found with country" + country);
			status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "SUCCESS");
		} else {
			status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "No Record found");
			throw new ResourceNotFoundException("country is not avilable" + country);

		}
		return new JobsResponseMessage(status, job);

	}

	@GetMapping("/getByLanguage/{language}")
	public JobsResponseMessage getJobByLang(@PathVariable("language") String language) {
		ResponseStatus status = null;
		List<Job> job = jobService.findJobByLanguage(language);
		if (job != null) {
			log.info("joa found using Language" + language);
			status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "SUCCESS");
		} else {
			log.error("job not found by using language" + language);
			status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "No Record found");
			throw new ResourceNotFoundException("language is not avilable" + language);

		}
		return new JobsResponseMessage(status, job);

	}

	@GetMapping("/getByType/{jobType}")
	public JobsResponseMessage getJobByType(@PathVariable("jobType") String jobType) {
		ResponseStatus status = null;
		List<Job> job = jobService.findJobByJobType(jobType);
		if (job != null) {
			log.info("jobs are found");
			status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "SUCCESS");
		} else {
			log.error("jobs are not found");
			status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "No Record found");
			throw new ResourceNotFoundException("JobType is not avilable" + jobType);

		}
		return new JobsResponseMessage(status, job);
	}

	@GetMapping("/getByExp/{experience}")
	public JobsResponseMessage getJobByExp(@PathVariable("experience") int experience) {
		ResponseStatus status = null;
		List<Job> job = jobService.findJobByExperience(experience);
		if (job != null) {
			log.info("job are found by usin experience");
			status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "SUCCESS");
		} else {
			log.error("job are not found");
			status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "No Record found");
			throw new ResourceNotFoundException("experience is not avilable" + experience);

		}
		return new JobsResponseMessage(status, job);
	}

	@GetMapping("/getBySkills/{skills}")
	public JobsResponseMessage getJobBySkills(@PathVariable("skills") String skills) {
		ResponseStatus status = null;
		List<Job> job = jobService.findJobBySkill(skills);
		if (job != null) {
			log.info("job are found by using skill" + skills);
			status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "SUCCESS");
		} else {
			log.error("job not found by using skill" + skills);
			status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "No Record found");
			throw new ResourceNotFoundException("skills is not avilable" + skills);

		}
		return new JobsResponseMessage(status, job);
	}

	@GetMapping("/getByAvailability/{availability}")
	public JobsResponseMessage getJobByAvailability(@PathVariable("availability") String availabiltyList) {
		ResponseStatus status = null;
		List<Job> job = jobService.findJobByAvailability(availabiltyList);

		if (job != null) {
			log.info("job are not found by using availability" + availabiltyList);
			status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "SUCCESS");
		} else {
			status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "No Record found");
			throw new ResourceNotFoundException("availability is not avilable" + availabiltyList);

		}
		return new JobsResponseMessage(status, job);

	}

	@GetMapping("/getPayrate/{payRate}")
	public JobsResponseMessage getJobByPayRate(@PathVariable("payRate") int payRate) {
		ResponseStatus status = null;
		List<Job> job = jobService.findJobByPayRate(payRate);
		if (job != null) {
			log.info("reords are found by using payrate" + payRate);
			status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "SUCCESS");
		} else {
			log.info("records are not found by using payrate " + payRate);
			status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "No Record found");
			throw new ResourceNotFoundException("payRate is not avilable" + payRate);

		}
		return new JobsResponseMessage(status, job);

	}

	@PostMapping("/processjobexcel")
	public String processExcel(@RequestParam("excelfile") MultipartFile excelfile) {
		return excelHelper.processExcel(excelfile);
	}
}
