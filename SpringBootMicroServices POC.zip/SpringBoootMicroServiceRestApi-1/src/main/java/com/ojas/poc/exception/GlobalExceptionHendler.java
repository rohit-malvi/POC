package com.ojas.poc.exception;

import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class GlobalExceptionHendler {
	private static final Logger log = Logger.getLogger(GlobalExceptionHendler.class);

	// hadnle custome Exception
	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<?> handleResourceNotFoundException(ResourceNotFoundException exception, WebRequest request) {
		log.error("Resource not found exception: ");
		ErrorDetail errorDetail = new ErrorDetail(new Date(), exception.getMessage(), request.getDescription(false));
		return new ResponseEntity(errorDetail, HttpStatus.NOT_FOUND);
	}

//handle globall  exception
	@ExceptionHandler(Exception.class)
	public ResponseEntity<?> handleGlobalException(ResourceNotFoundException exception, WebRequest request) {
		log.error("exception: ");
		ErrorDetail errorDetail = new ErrorDetail(new Date(), exception.getMessage(), request.getDescription(false));
		return new ResponseEntity(errorDetail, HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
