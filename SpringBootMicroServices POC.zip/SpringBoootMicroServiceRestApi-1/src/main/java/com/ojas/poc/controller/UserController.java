package com.ojas.poc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ojas.poc.model.UserInfo;
import com.ojas.poc.response.JobResponseMessage;
import com.ojas.poc.response.ResponseStatus;
import com.ojas.poc.response.ResponseStatusCode;
import com.ojas.poc.service.UserInfoService;

@RestController
@RequestMapping(value = "/user")
public class UserController {
	@Autowired
	private UserInfoService userInfoService;

	@PostMapping("/saveUser")
	public int createUser(@RequestBody UserInfo user) {

		int userId = userInfoService.createUser(user);
		return userId;

	}

	@GetMapping("/getById/{userId}")
	public JobResponseMessage<UserInfo> getUserById(@PathVariable int userId) {
		ResponseStatus status = null;
		if (userInfoService.findByUserId(userId) != null) {
			status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "SUCCESS");
		} else {
			status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "No Record found");

		}
		return new JobResponseMessage<UserInfo>(status, userInfoService.findByUserId(userId));

	}

	@GetMapping("/userName/{userName}")
	public UserInfo getUserName(@PathVariable("userName") String userName) {

		return userInfoService.findByName(userName);

	}
}
