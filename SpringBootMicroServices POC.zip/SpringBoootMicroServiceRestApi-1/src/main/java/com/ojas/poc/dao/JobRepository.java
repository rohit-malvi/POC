package com.ojas.poc.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ojas.poc.model.Job;

public interface JobRepository extends JpaRepository<Job, Integer> {
	
	//create,get,getall

	public List<Job> findJobByCountry(String country);

	public List<Job> findJobByLanguage(String lang);

	public List<Job> findJobByJobType(String type);
	
	public List<Job> findJobByExperience(int exp);
	
	public List<Job> findJobBySkills(String skill);
	
	public List<Job> findJobByPayRate(int payRate);
	
	public List<Job> findJobByAvailability(String availabiltyList);
	
//	public void postBulkJobs(List<Job> userInfo);


	
}
