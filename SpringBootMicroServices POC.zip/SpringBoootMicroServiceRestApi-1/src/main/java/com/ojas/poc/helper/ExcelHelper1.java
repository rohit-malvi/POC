package com.ojas.poc.helper;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.ojas.poc.controller.JobController;
import com.ojas.poc.controller.UserController;
import com.ojas.poc.model.Job;
import com.ojas.poc.model.UserInfo;
import com.ojas.poc.service.ExcelService1;
import com.ojas.poc.service.UserInfoService;

@Service
public class ExcelHelper1 {

	private static final Logger log = LogManager.getLogger(ExcelHelper1.class);

	@Autowired
	private ExcelService1 excelService1;

	@Autowired
	private JobController jobCont;

	@Autowired
	private UserInfoService userService;

	@Autowired
	private UserController userHelper;
	

	public String processExcel(MultipartFile excelfile) {
		try {
			int i = 1;
			XSSFWorkbook workbook = new XSSFWorkbook(excelfile.getInputStream());
			XSSFSheet worksheet = workbook.getSheetAt(0);
			while (i <= worksheet.getLastRowNum()) {
				XSSFRow row = worksheet.getRow(i++);
				Job job = null;
				UserInfo userInfo =  userService.findByName(row.getCell(2).getStringCellValue());
				if (userInfo != null) {
					job = inserBulkJob(job, row, userInfo);
					jobCont.createJob(job);

				} else {
					UserInfo entity = new UserInfo();
					entity.setUserName(row.getCell(2).getStringCellValue());
					int id = userHelper.createUser(entity);
					UserInfo user = userService.findByUserId(id);
					job = inserBulkJob(job, row, user);
					jobCont.createJob(job);
				}
			}
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Uploded Sucessfully..!!";
	}

	public Job insertJob(Job job, UserInfo user) {
		Job jobEntity = new Job();
		jobEntity.setJobTitle(job.getJobTitle());
		jobEntity.setJobDescription(job.getJobDescription());
		jobEntity.setCountry(job.getCountry());
		jobEntity.setState(job.getState());
		jobEntity.setAvailability(job.getAvailability());
		jobEntity.setReplyRate(job.getReplyRate());
		jobEntity.setPayRate(job.getPayRate());
		jobEntity.setExperience(job.getExperience());
		jobEntity.setSkills(job.getSkills());
		jobEntity.setLanguage(job.getLanguage());
		jobEntity.setJobType(job.getJobType());
		jobEntity.setUserInfo(user);
		return jobEntity;
	}

	public Job inserBulkJob(Job job, XSSFRow row, UserInfo user) {
		job = new Job();
		job.setJobTitle(row.getCell(0).getStringCellValue());
		job.setJobDescription(row.getCell(1).getStringCellValue());
		job.setCountry(row.getCell(3).getStringCellValue());
		job.setState(row.getCell(4).getStringCellValue());
		job.setAvailability(row.getCell(5).getStringCellValue());
		job.setReplyRate(Integer.parseInt(row.getCell(6).getStringCellValue()));
		job.setPayRate(Integer.parseInt(row.getCell(7).getStringCellValue()));
		job.setExperience(Integer.parseInt(row.getCell(8).getStringCellValue()));
		job.setSkills(row.getCell(9).getStringCellValue());
		job.setLanguage(row.getCell(10).getStringCellValue());
		job.setJobType(row.getCell(11).getStringCellValue());
		job.setUserInfo(user);
		return job;
	}

}
