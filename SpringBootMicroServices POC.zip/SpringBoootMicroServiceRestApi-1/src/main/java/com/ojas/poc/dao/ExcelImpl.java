package com.ojas.poc.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ojas.poc.controller.JobController;
import com.ojas.poc.model.Job;
import com.ojas.poc.model.UserInfo;

@Repository
@Transactional
@SuppressWarnings("unchecked")
@Configuration
public class ExcelImpl implements Excel1 {
	private static final Logger log = Logger.getLogger(JobController.class);

	@Autowired
	private EntityManager entityManager;

	private Session getSession() {
		return entityManager.unwrap(Session.class);
	}

	@Override
	public void postBulkJobs(List<Job> jobs) {
		log.info("Entered postBulkJobs for JobDao::");
		try {
			if (jobs != null && jobs.size() > 0) {
				for (Job job : jobs) {
					getSession().persist(job);
				}
			}
		} catch (Exception ex) {
			log.error("Failed adding Jobs List for JobDao:: ", ex);
		}
	}

	@Override
	public int createUser(UserInfo userInfo) {
		log.info("Entered createUser for UserDao::");
		int id = 0;
		try {
			id = (int) getSession().save(userInfo);
			log.info("User Saved SuccessFully for UserDao.");
		} catch (Exception ex) {
			log.error("UserInfo Registration Failed for UserDao :: ", ex);
		}
		return id;
	}

	@Override
	public int createJob(Job job) {
		log.info("Entered createJob for JobDao::");
		int id = 0;
		try {
			id = (int) getSession().save(job);
			log.info("Job Saved SuccessFully for JobDao.");
		} catch (Exception ex) {
			log.error("Job Registration Failed for JobDao :: ", ex);
		}
		return id;
	}

}
