package com.ojas.poc.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ojas.poc.model.UserInfo;

public interface UserInfoRepository extends JpaRepository<UserInfo, Integer> {
	
	//create user, get by id
	public UserInfo findJobByUserName(String userName);
}
