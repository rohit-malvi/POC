package com.ojas.poc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ojas.poc.dao.ExcelImpl;
import com.ojas.poc.dao.UserInfoRepository;
import com.ojas.poc.model.UserInfo;

@Service
public class UserInfoService {
	@Autowired
	private UserInfoRepository userInfoRepository;

	@Autowired
	private ExcelImpl excelrepo;

//	public UserInfo createUser(UserInfo user) {
//		return userInfoRepository.save(user);
//	}

	public int createUser(UserInfo userInfo) {
		// TODO Auto-generated method stub
		return excelrepo.createUser(userInfo);
	}

	public UserInfo findByUserId(int userId) {
		return userInfoRepository.findById(userId).orElse(null);
	}

	public UserInfo findByName(String name) {
		return  userInfoRepository.findJobByUserName(name);
	}
}
