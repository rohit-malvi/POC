package com.ojas.poc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ojas.poc.dao.ExcelImpl;
import com.ojas.poc.model.Job;

@Service
public class ExcelService1 {

	@Autowired
	private ExcelImpl excelDao;

	public void postBulkJobs(List<Job> jobs) {
		// TODO Auto-generated method stub
		excelDao.postBulkJobs(jobs);
	}

}
