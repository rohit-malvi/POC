package com.ojas.poc.dao;

import java.util.List;

import com.ojas.poc.model.Job;
import com.ojas.poc.model.UserInfo;

public interface Excel1 {
	
	public void postBulkJobs(List<Job> userInfo);//
	public int createUser(UserInfo userInfo);
	public int createJob(Job job);
}
